You can create a `description.txt` file in the top level of your mod's source directory.

This file is a plain text file that contains a short description of your mod. In game, it will appear in the Mods menu when the More Info button is selected. The description file is handled as plain-text and thus any formatting (such as markdown) will not be handled.

Including a `description.txt` is very important and helps players find mods they are interested in.

### description_workshop.txt

An additional file, `decription_workshop.txt`, can optionally be included. If present, the content of this text file will automatically be placed on the mod's Workshop page when uploading or updating the mod instead of the `description.txt`. The regular `description.txt` will still be displayed in game. [BB Code markup tags](https://steamcommunity.com/comment/ForumTopic/formattinghelp) can be included in the `decription_workshop.txt` which Steam will parse.