When learning to create mod Projectiles, it is beneficial learn the effect of various Projectile properties by seeing how vanilla projectiles achieve their desired effects. Below is a listing of the properties set for each vanilla Terraria Projectile. 

For example. If you wanted your mod Projectile to not collide with tiles like the Vilethorn, you could find the Vilethorn on the spreadsheet and find that the Vilethorn projectile sets tileCollide to false. From this, you learn that you can set your own projectile to not collide with tiles by setting tileCollide to false.

- [Vanilla Projectile Field Values Spreadsheet](https://terraria.wiki.gg/wiki/Projectile_IDs)