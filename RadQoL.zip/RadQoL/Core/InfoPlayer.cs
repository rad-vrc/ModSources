using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;
using Terraria.Localization;
using RadQoL.Content.Items.Tools; // AiPhone, AiPhoneInfo

namespace RadQoL.Core
{
    // Biome 情報表示用の最小限 ModPlayer 実装
    public partial class InfoPlayer : ModPlayer
    {
        public bool biomeDisplay;
        public List<string> biomeNames;
        public int displayTimer; // 経過フレーム
        public static readonly List<string> EmptyList = new List<string>(0);

        public override void Initialize()
        {
            biomeNames = new List<string>();
        }

        public override void ResetInfoAccessories()
        {
            biomeDisplay = false;
        }

        public override void RefreshInfoAccessoriesFromTeamPlayers(Player otherPlayer)
        {
            if (otherPlayer.GetModPlayer<InfoPlayer>().biomeDisplay)
                biomeDisplay = true;
        }

        public override void PreUpdate()
        {
            // 参照実装互換: 1tickごと増加し 4000 超でリセット
            if (++displayTimer > 4000)
                displayTimer = 0;
        }

        public override void PostUpdate()
        {
            // After vanilla ResetInfoAccessories, (re)apply info effects when AiPhone is present
            try
            {
                if (HasAiPhone(Player))
                {
                    AiPhoneInfo.Apply(Player);
                }
            }
            catch { /* never crash */ }

            // 1秒毎に再計算
            if (biomeDisplay && (biomeNames == null || Main.GameUpdateCount % 60 == 0))
            {
                // Use the new MOD biome detection system from InfoPlayer.ModBiomes.cs
                biomeNames = GetBiomes(Player, prioModBiomes: true);
                
                // Fallback to basic vanilla detection if no biomes found
                if (biomeNames.Count == 0)
                    biomeNames = GetCurrentBiomes();
            }
        }

        private static bool HasAiPhone(Player p)
        {
            try
            {
                int type = ModContent.ItemType<AiPhone>();
                // Inventory (0..58); include trash slot as needed
                for (int i = 0; i < p.inventory.Length; i++)
                {
                    var item = p.inventory[i];
                    if (item != null && item.type == type && item.stack > 0)
                        return true;
                }
            }
            catch { }
            return false;
        }

        private List<string> GetCurrentBiomes()
        {
            var list = new List<string>();
            Player p = Player;

            if (p.townNPCs > 2f && !p.ZoneShadowCandle)
                list.Add(Language.GetTextValue("Mods.RadQoL.Biomes.Vanilla.Town"));
            if (p.ZoneUnderworldHeight)
                list.Add(Language.GetTextValue("Mods.RadQoL.Biomes.Vanilla.Underworld"));
            else if (p.ZoneSkyHeight)
                list.Add(Language.GetTextValue("Mods.RadQoL.Biomes.Vanilla.Space"));
            else if (p.ZoneRockLayerHeight || p.ZoneDirtLayerHeight)
                list.Add(Language.GetTextValue("Mods.RadQoL.Biomes.Vanilla.Underground"));
            if (p.ZoneBeach)
                list.Add(Language.GetTextValue("Mods.RadQoL.Biomes.Vanilla.Ocean"));
            if (p.ZoneSnow)
                list.Add(Language.GetTextValue("Mods.RadQoL.Biomes.Vanilla.Snow"));
            if (p.ZoneDesert || p.ZoneUndergroundDesert)
                list.Add(Language.GetTextValue("Mods.RadQoL.Biomes.Vanilla.Desert"));
            if (p.ZoneJungle)
                list.Add(Language.GetTextValue("Mods.RadQoL.Biomes.Vanilla.Jungle"));
            if (p.ZoneHallow)
                list.Add(Language.GetTextValue("Mods.RadQoL.Biomes.Vanilla.Hallow"));
            if (p.ZoneCorrupt)
                list.Add(Language.GetTextValue("Mods.RadQoL.Biomes.Vanilla.Corruption"));
            if (p.ZoneCrimson)
                list.Add(Language.GetTextValue("Mods.RadQoL.Biomes.Vanilla.Crimson"));
            if (p.ZoneGlowshroom)
                list.Add(Language.GetTextValue("Mods.RadQoL.Biomes.Vanilla.Shroom"));
            if (p.ZoneDungeon)
                list.Add(Language.GetTextValue("Mods.RadQoL.Biomes.Vanilla.Dungeon"));
            if (p.ZoneMeteor)
                list.Add(Language.GetTextValue("Mods.RadQoL.Biomes.Vanilla.Meteor"));
            if (p.ZoneGranite)
                list.Add(Language.GetTextValue("Mods.RadQoL.Biomes.Vanilla.Granite"));
            if (p.ZoneMarble)
                list.Add(Language.GetTextValue("Mods.RadQoL.Biomes.Vanilla.Marble"));
            if (p.ZoneLihzhardTemple)
                list.Add(Language.GetTextValue("Mods.RadQoL.Biomes.Vanilla.Temple"));
            if (p.ZoneGraveyard)
                list.Add(Language.GetTextValue("Mods.RadQoL.Biomes.Vanilla.Graveyard"));

            if (list.Count == 0)
                list.Add(Language.GetTextValue("Mods.RadQoL.Biomes.Vanilla.Forest"));

            var seen = new HashSet<string>();
            var dedup = new List<string>();
            foreach (var b in list)
                if (seen.Add(b)) dedup.Add(b);
            return dedup;
        }
    }
}
