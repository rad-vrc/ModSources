namespace RadQoL.Common.Config
{
    public class SplittableGrabBags
    {
        public bool Enabled = true;
        public bool ShowTooltip = true;
        public override bool Equals(object obj) => obj is SplittableGrabBags s && Enabled == s.Enabled && ShowTooltip == s.ShowTooltip;
        public override int GetHashCode() => System.HashCode.Combine(Enabled, ShowTooltip);
    }
}
