global using TranslateTest2.Common.Utilities;
